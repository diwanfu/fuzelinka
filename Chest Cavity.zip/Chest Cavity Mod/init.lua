-- Mod Chest Cavity
chest_cavity = {}

-- Définition des organes
chest_cavity.organs = {
    heart = {
        description = "Cœur Humain",
        max_count = 1,
        texture = "chest_cavity_heart.png",
        slot = 4, -- Position au-dessus de la colonne vertébrale
    },
    spine = {
        description = "Colonne Vertébrale",
        max_count = 1,
        texture = "chest_cavity_spine.png",
        slot = 13, -- Position centrale
    },
    lung_left = {
        description = "Poumon Gauche",
        max_count = 1,
        texture = "chest_cavity_lung_left.png",
        slot = 3, -- À gauche du cœur
    },
    lung_right = {
        description = "Poumon Droit",
        max_count = 1,
        texture = "chest_cavity_lung_right.png",
        slot = 5, -- À droite du cœur
    },
    kidney_left = {
        description = "Rein Gauche",
        max_count = 1,
        texture = "chest_cavity_kidney_left.png",
        slot = 12, -- À gauche de la colonne vertébrale
    },
    kidney_right = {
        description = "Rein Droit",
        max_count = 1,
        texture = "chest_cavity_kidney_right.png",
        slot = 14, -- À droite de la colonne vertébrale
    },
    liver = {
        description = "Foie Humain",
        max_count = 2,
        texture = "chest_cavity_liver.png",
        slot = 15,
    },
    stomach = {
        description = "Estomac Humain",
        max_count = 1,
        texture = "chest_cavity_stomach.png",
        slot = 22, -- Position sous la colonne vertébrale
    },
}

-- Fonctions pour gérer les effets des organes

local function check_heart(player)
    local inv = player:get_inventory()
    local heart_stack = inv:get_stack("chest_cavity", chest_cavity.organs.heart.slot)
    if heart_stack:is_empty() then
        player:set_hp(player:get_hp() - 1) -- Inflige 1 point de dégâts par seconde
    end
end

local function check_lungs(player)
    local inv = player:get_inventory()
    local lung_left = inv:get_stack("chest_cavity", chest_cavity.organs.lung_left.slot)
    local lung_right = inv:get_stack("chest_cavity", chest_cavity.organs.lung_right.slot)
    if lung_left:is_empty() and lung_right:is_empty() then
        player:set_hp(player:get_hp() - 0.5) -- Inflige 0.5 point de dégâts par seconde
    end
end

local function check_spine(player)
    local inv = player:get_inventory()
    local spine_stack = inv:get_stack("chest_cavity", chest_cavity.organs.spine.slot)
    if spine_stack:is_empty() then
        player:set_physics_override({ speed = 0, jump = 0, gravity = 1 })
    else
        player:set_physics_override({ speed = 1, jump = 1, gravity = 1 })
    end
end

local function check_kidneys(player)
    local inv = player:get_inventory()
    local kidney_left = inv:get_stack("chest_cavity", chest_cavity.organs.kidney_left.slot)
    local kidney_right = inv:get_stack("chest_cavity", chest_cavity.organs.kidney_right.slot)
    if kidney_left:is_empty() and kidney_right:is_empty() then
        player:set_physics_override({ speed = 2, jump = 0.5, gravity = 0.5 })
    else
        player:set_physics_override({ speed = 1, jump = 1, gravity = 1 })
    end
end

local function check_stomach(player)
    local inv = player:get_inventory()
    local stomach_stack = inv:get_stack("chest_cavity", chest_cavity.organs.stomach.slot)
    if stomach_stack:is_empty() then
        if minetest.global_exists("hbhunger") and hbhunger.set_hunger then
            hbhunger.set_hunger(player, 0) -- Vide la barre de faim
        end
    end
end

-- Timer global pour appliquer les effets en continu
local timers = {}
minetest.register_globalstep(function(dtime)
    for _, player in ipairs(minetest.get_connected_players()) do
        local name = player:get_player_name()
        timers[name] = (timers[name] or 0) + dtime
        if timers[name] >= 1 then
            check_heart(player)
            check_lungs(player)
            check_spine(player)
            check_kidneys(player)
            check_stomach(player)
            timers[name] = 0
        end
    end
end)

-- Initialisation des organes du joueur
minetest.register_on_joinplayer(function(player)
    local inv = player:get_inventory()
    inv:set_size("chest_cavity", 27)
    for name, organ in pairs(chest_cavity.organs) do
        local stack = inv:get_stack("chest_cavity", organ.slot)
        if stack:is_empty() then
            inv:set_stack("chest_cavity", organ.slot, "chest_cavity:" .. name)
        end
    end
end)

-- Enregistrement des organes comme objets
for name, organ in pairs(chest_cavity.organs) do
    minetest.register_craftitem("chest_cavity:" .. name, {
        description = organ.description,
        inventory_image = organ.texture,
    })
end

-- Enregistrement du scalpel
minetest.register_craftitem("chest_cavity:scalpel", {
    description = "Scalpel",
    inventory_image = "chest_cavity_scalpel.png",
    on_use = function(itemstack, user, pointed_thing)
        local formspec = "size[8,10]" ..
                         "label[0,0;Inventaire d'organes]" ..
                         "list[current_player;chest_cavity;0,1;9,3;]" ..
                         "list[current_player;main;0,5;8,4;]"
        minetest.show_formspec(user:get_player_name(), "chest_cavity:inventory", formspec)
    end,
})

